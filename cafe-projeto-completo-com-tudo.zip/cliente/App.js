import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, TouchableOpacity, Alert } from 'react-native';

const cafes = ['Expresso', 'Cappuccino', 'Latte', 'Mocha', 'Macchiato'];

export default function App() {
  const [nome, setNome] = useState('');
  const [cafeSelecionado, setCafeSelecionado] = useState(null);

  const enviarPedido = async () => {
    if (!nome || !cafeSelecionado) {
      Alert.alert('Preencha todos os campos!');
      return;
    }

    try {
      await fetch('http://192.168.0.100:3000/pedido', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, cafe: cafeSelecionado }),
      });
      Alert.alert('Pedido enviado com sucesso!');
      setNome('');
      setCafeSelecionado(null);
    } catch (error) {
      Alert.alert('Erro ao enviar pedido', error.message);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20, marginTop: 50 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold' }}>Cafés disponíveis</Text>
      <FlatList
        data={cafes}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => setCafeSelecionado(item)}>
            <Text style={{
              padding: 10,
              backgroundColor: item === cafeSelecionado ? '#ddd' : '#fff',
              marginVertical: 5,
              borderRadius: 5
            }}>
              {item}
            </Text>
          </TouchableOpacity>
        )}
        keyExtractor={(item, index) => index.toString()}
      />
      <TextInput
        placeholder="Digite seu nome"
        value={nome}
        onChangeText={setNome}
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          marginTop: 20,
          padding: 10,
          borderRadius: 5,
        }}
      />
      <Button title="Enviar pedido" onPress={enviarPedido} />
    </View>
  );
}