import React, { useEffect, useState } from 'react';
import { View, Text, FlatList } from 'react-native';

export default function App() {
  const [pedidos, setPedidos] = useState([]);

  const buscarPedidos = async () => {
    try {
      const response = await fetch('http://192.168.0.100:3000/pedidos');
      const data = await response.json();
      setPedidos(data);
    } catch (error) {
      console.log('Erro ao buscar pedidos:', error.message);
    }
  };

  useEffect(() => {
    buscarPedidos();
    const interval = setInterval(buscarPedidos, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <View style={{ flex: 1, padding: 20, marginTop: 50 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold' }}>Pedidos Recebidos</Text>
      <FlatList
        data={pedidos}
        renderItem={({ item }) => (
          <Text style={{
            padding: 10,
            backgroundColor: '#eee',
            marginVertical: 5,
            borderRadius: 5
          }}>
            {item.nome} pediu um {item.cafe}
          </Text>
        )}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
}