const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

let pedidos = [];

app.post('/pedido', (req, res) => {
  const { nome, cafe } = req.body;
  pedidos.push({ nome, cafe });
  res.sendStatus(200);
});

app.get('/pedidos', (req, res) => {
  res.json(pedidos);
});

app.listen(3000, () => console.log('Servidor rodando na porta 3000'));